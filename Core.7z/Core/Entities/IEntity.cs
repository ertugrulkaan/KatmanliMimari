﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    // IEntity implement eden bir class veritabani tablosudur.
    public interface IEntity
    {
    }
}
